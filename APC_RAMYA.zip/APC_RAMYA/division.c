#include "operation.h"
#include "main.h"

int division(APC *head1, APC *tail1, APC *head2, APC *tail2, APC **headR, APC **tailR)
{
    int count = 0;
    int res;

        res = compare_list(head1,head2);
        if(res == OPERAND2)
        {
            count = 0;
        }
        else
        {
            while(res != OPERAND2)
            {  
                subtraction(tail1, tail2, headR,tailR);
                count++;
                remove_pre_zeros(&head1, &tail1);
                delete_list(&head1, &tail1);
                head1 = *headR;
                tail1 = *tailR;
                res = compare_list(head1,head2);
            
                *headR = NULL;
                *tailR = NULL;

               if(res == OPERAND2)
                {
                    break;
                }

            }

        }
    return count;
}