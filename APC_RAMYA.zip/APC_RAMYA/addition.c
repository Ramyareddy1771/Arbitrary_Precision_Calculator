#include "operation.h"
#include "main.h"

void addition(APC *tail1, APC *tail2, APC **headR, APC **tailR)
{
    APC *temp1 = tail1;   // Last digit of operand1
    APC *temp2 = tail2;   // Last digit of operand2

    int carry = 0;        // Stores carry

    while(temp1 != NULL || temp2 != NULL)
    {
        int dig1 = 0;
        int dig2 = 0;

        // Get digit from operand1
        if(temp1 != NULL)
        {
            dig1 = temp1->data;
            temp1 = temp1->prev;
        }

        // Get digit from operand2
        if(temp2 != NULL)
        {
            dig2 = temp2->data;
            temp2 = temp2->prev;
        }

        // Add digits and carry
        int sum = dig1 + dig2 + carry;

        carry = sum / 10;

        // Insert unit digit into result list
        insert_first(headR, tailR, sum % 10);
    }

    // Insert remaining carry
    if(carry)
    {
        insert_first(headR, tailR, carry);
    }
   // print_list(headR, tailR);
}