#ifndef MAIN_H
#define MAIN_H


#include<stdio.h>


#define SUCCESS 0
#define FAILURE -1
#define LIST_EMPTY -2

#define SAME 1
#define OPERAND1 2
#define OPERAND2 3

typedef struct APC
{
    int data;
    struct APC *prev;
    struct APC *next;
}APC;

int insert_first(APC **head , APC **tail, int data);
int insert_last(APC **head , APC **tail, int data);
int print_list(APC **head, APC **tail);
int cla_validation(int argc, char *argv[]);
void remove_pre_zeros(APC **headR, APC **tailR);
int delete_first(APC **head, APC **tail);
int delete_list(APC **head, APC **tail);
int compare_list(APC *head1, APC *head2);

#endif