
#include <stdio.h>
#include <string.h>
#include "main.h"
#include "ui.h"

int cla_validation(int argc, char *argv[])
{
    
    /*  Check number of arguments */
    if(argc != 4) 
    {
        printf(RED "Error : Invalid number of arguments\n" RESET);
        printf("Usage: ./a.out <operand1> <operator> <operand2>\n");
        return -1;
    }

  /* validate operators*/
  if(!(strcmp(argv[2], "+")== 0 || strcmp(argv[2], "-")== 0 ||
        strcmp(argv[2], "*")== 0 || strcmp(argv[2], "/")== 0 ||
        strcmp(argv[2], "x")==0 || strcmp(argv[2], "X")==0))
        {
            printf(RED "Error : Invalid operator\n" RESET);
            printf("Valid operators : + - / * X x\n");
            return -1;
        }

    int i = 0;
    /*if first charcater is + or - then skip */
    if(argv[1][0] == '+' || argv[1][0] == '-')
    {
        i = 1; //skip sign
    }

    /* check for both operands must be numeric */
    for(; argv[1][i] != '\0'; i++) // for operand 1
    {
        if(argv[1][i] < '0' || argv[1][i] > '9')
        {
            printf(RED "Error : Operands must be numeric value\n" RESET);
            return -1;
        }
    }
    int j = 0;
    if(argv[3][0] == '+' || argv[3][0] == '-')
    {
        j = 1; //skip sign
    }
   
    for(; argv[3][j] != '\0'; j++) // for operand 2
    {
        if(argv[3][j] < '0' || argv[3][j] > '9')
        {
            printf(RED "Error : Operands must be numeric value\n" RESET);
            return -1;
        }
    }
return 0; //success
}