#include "operation.h"
#include "main.h"

void subtraction(APC *tail1, APC *tail2, APC **headR, APC **tailR)
{
    *headR = NULL;
    *tailR = NULL;
    
    APC *temp1 = tail1;  // Points to last digit of operand1
    APC *temp2 = tail2;  // Points to last digit of operand2

    int borrow = 0;      // Stores borrow value

    // Traverse both lists from right to left
    while(temp1 != NULL || temp2 != NULL)
    {
        int dig1 = 0;
        int dig2 = 0;

        // Get digit from operand1
        if(temp1 != NULL)
        {
            dig1 = temp1->data;
            temp1 = temp1->prev;
        }

        // Get digit from operand2
        if(temp2 != NULL)
        {
            dig2 = temp2->data;
            temp2 = temp2->prev;
        }

        // Apply previous borrow
        dig1 = dig1 - borrow;

        // Check whether borrow is required
        if(dig1 < dig2)
        {
            dig1 = dig1 + 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        // Perform subtraction
        int res = dig1 - dig2;

        // Insert result digit at beginning
        insert_first(headR, tailR, res);
    }
    remove_pre_zeros(headR,tailR);
   
}