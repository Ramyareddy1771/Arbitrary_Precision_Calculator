#include "operation.h"
#include "main.h"

void multiplication(APC *tail1, APC *tail2, APC **headR, APC **tailR)
{
    int prod = 0;
    int carry = 0;
    int count = 0;
    int k;

    APC *t1 = tail1;
    APC *t2 = tail2;

    APC *headR2 = NULL;
    APC *tailR2 = NULL;

    APC *headAR = NULL;
    APC *tailAR = NULL;

    /* Traverse operand2 from last digit */
    while(t2 != NULL)
    {
        carry = 0;
        t1 = tail1;

        /* Create f temporary result list */
        headR2 = NULL;
        tailR2 = NULL;

        /*
         * Add trailing zeros according to position.
         * Example:
         * 123 x 45
         * First partial product -> 123 x 5
         * Second partial product -> 123 x 4 + one zero
         */

        /* Add required  zeroes */
        for(k = 0; k < count; k++)
        {
            insert_last(&headR2, &tailR2, 0);
        }

        /* Multiply current digit of operand2 with all digits of operand1 */
        while(t1 != NULL)
        {
            prod = (t1->data * t2->data) + carry;

            carry = prod / 10;

            insert_first(&headR2,&tailR2,prod % 10);

            t1 = t1->prev;
        }

        /* Insert remaining carry */
        if(carry)
        {
            insert_first(&headR2,&tailR2,carry);
        }

        /* First multiplication result */
        if(count == 0)
        {
            *headR = headR2;
            *tailR = tailR2;
        }
        else
        {
            headAR = NULL;
            tailAR = NULL;

            /* Add previous result and current result */
            addition(*tailR,tailR2,&headAR,&tailAR);

            /* Delete previous result list */
            delete_list(headR, tailR);

            *headR = headAR;
            *tailR = tailAR;
        }

        t2 = t2->prev;
        count++;
    }

    remove_pre_zeros(headR, tailR);

    //print_list(headR, tailR);
}