
#include "main.h"
#include "operation.h"
#include "ui.h"
#include <stdio.h>
#include <stdlib.h>

int insert_last(APC **head , APC **tail, int data)
{
    /* create newnode and allocate memory dynamically */
    APC *new = (APC*)malloc(sizeof(APC));

    /* check memory allocation */
    if(new == NULL)
    {
        return -1;
    }

    /* initialize its fields */
    new->data = data; //assign data
    new->prev = NULL; //upadate prev with null
    new->next = NULL; //update next with null
    
    if(*head == NULL) //if list is empty
    {
        *head = new;
        *tail = new;
    }
    else
    {
        /* link current last node's next ptr to new node */
        (*tail)->next = new;

        /* set new node's prev ptr to old tail node */
        new->prev = *tail;

        /* as new node is last node now then it should be null*/
        new->next = NULL;

        /* update tail to point to new node */
        *tail = new; 
    }
    return 0;
}

int insert_first(APC **head , APC **tail, int data)
{
     /* create newnode and allocate memory dynamically */
    APC *new = (APC*)malloc(sizeof(APC));

    /* check memory allocation */
    if(new == NULL)
    {
        return -1;
    }

    /* initialize its fields */
    new->data = data; //assign data
    new->prev = NULL; //upadate prev with null
    new->next = NULL; //update next with null

    if(*head == NULL) //if list is empty
    {
        *head = new; 
        *tail = new;
    }
    else
    {
        /* link new node next ptr to head */
        new->next = *head;

        /* Set new node's prev ptr to old tail node*/
        (*head)->prev = new;

        /* update head to point to new node */
        *head = new;
    }
    return 0;
}
int delete_first(APC **head, APC **tail)
{
    if(*head == NULL)
    {
        return -1;
    }
    
  APC *temp; 
  
  temp = *head;
  
  if((*head) -> next == NULL)
  {
      *head = NULL;
      *tail = NULL;
     
      free(temp);
      return 0;
  }
  
  *head = temp->next;
  (*head)->prev = NULL;

   temp->next = NULL;
   free(temp);
  return 0;
  
}

int delete_list(APC **head, APC **tail)
{
    if(*head == NULL)
    {
        return -2;
    }

    APC *temp;

    while(*head != NULL)
    {
        temp = *head;

        *head = (*head)->next;

        free(temp);
    }

    *tail = NULL;

    return 0;
}
int compare_list(APC *head1, APC *head2)
{
    int list1_count = 0;
    int list2_count = 0;

    APC *temp1 = head1;
    APC *temp2 = head2;

    // while(temp1 && temp1->data == 0)
    // {
    //     temp1 = temp1->next;
    // }
    // while(temp2 && temp2->data == 0)
    // {
    //     temp2 = temp2->next;
    // }
    // Count digits in operand1
    while(temp1 != NULL)
    {
        list1_count++;
        temp1 = temp1->next;
    }

    // Count digits in operand2
    while(temp2 != NULL)
    {
        list2_count++;
        temp2 = temp2->next;
    }

    temp1 = head1;
    temp2 = head2;

    // Operand1 has more digits
    if(list1_count > list2_count)
        return OPERAND1;

    // Operand2 has more digits
    if(list1_count < list2_count)
        return OPERAND2;

    // Same number of digits, compare digit by digit
    while(temp1 != NULL)
    {
        if(temp1->data > temp2->data)
            return OPERAND1;

        if(temp1->data < temp2->data)
            return OPERAND2;

        temp1 = temp1->next;
        temp2 = temp2->next;
    }

    // Both operands are equal
    return SAME;
}
void remove_pre_zeros(APC **headR, APC  **tailR)
{
    if( *headR == NULL)
       return;

    while ((*headR)->data == 0 && (*headR)->next != NULL)
    {
        delete_first(headR, tailR);
    }
}
int print_list(APC **head, APC **tail)
{
    /* Checking if list empty or not */
    if(*head == NULL || *tail == NULL)
    {
        return -2;
    }
    APC *temp = *head;
        printf(MAGENTA"Head -> " RESET);
        while(temp != NULL)
        {
            /* Printing the list */
            printf("%d ",temp->data);

            if(temp -> next != NULL)
            {
                printf(MAGENTA"<-> " RESET);
            }
            /* Traversing in forward direction */
            temp = temp->next;
        }
        printf(MAGENTA"<- Tail\n" RESET);
        return 0;

}