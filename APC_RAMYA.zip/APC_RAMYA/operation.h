#ifndef OPERATION_H
#define OPERATION_H

#include "main.h"

void addition(APC *tail1,APC *tail2, APC **headR, APC **tailR);
void subtraction(APC *tail1,APC *tail2, APC **headR, APC **tailR);
void multiplication(APC *tail1, APC *tail2, APC **headR, APC **tailR);
int division(APC *head1, APC *tail1, APC *head2, APC *tail2, APC **headR, APC **tailR);
#endif