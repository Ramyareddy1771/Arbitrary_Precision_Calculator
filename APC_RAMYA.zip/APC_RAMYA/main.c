/*************************************************************************************************************************************************************** 
 * Name             : RAMYA AMBATI
 * REGNO            : 25048_059
 * Project Title    : Arbitrary Precision Calculator-APC
 * Objective        : To perform arithmetic operations on large numbers using linked list data structure.
 * Description      : This project is to design and implement an Arbitrary Precision Calculator in C programming language.
 *                     that can perform arithmetic operations on large numbers (such as addition, subtraction, multiplication, and division) 
 *                     that exceed the limits of standard data types. The calculator will use double linked lists to represent and manipulate these large numbers, 
 *                     allowing for precise calculations.
 * Operations       : Prototypes of operations are defined in operation.h and implemented in their respective files (addition.c, subtraction.c, multiplication.c, division.c).
 * Input            : Input is taken from command line arguments and validated in main.c. The calculator supports both positive and negative numbers.
 *                    List1 = operand ,List2 = operand2 , operators = +,-,*,x,X,/ 
 * Output           : The result of the arithmetic operation is printed to the console. 
 *                     Status (SUCCESS/FAILURE)
 *                    The calculator handles leading zeros and displays the result in a human-readable format.
 * To Compile       : gcc *.c
 * To Run           : ./a.out <operand1> <operator> <operand2>
 *      
 * 
*/
#include "main.h"
#include "operation.h"
#include "ui.h"
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int sign1 = 1,sign2 = 1;
int main(int argc,char *argv[])
{
    if(argc <= 1)
    {
        printf(RED "ERROR: No arguments provided!\n" RESET);
        return -1;
    }
    APC *head1 = NULL, *tail1 = NULL; // for list1(operand1)
    APC *head2 = NULL, *tail2 = NULL; // for list2(operand2)
    APC *headR = NULL, *tailR = NULL; // for result list
    
    //printf("argc = %d\n", argc);

    // Validation
     int res =cla_validation(argc, argv);
	 	
      // Create 2 lists of operands
	if(res != -1)
    {
      if(argv[1][0] == '-')
		sign1 = -1;
	  if(argv[3][0] == '-')
		sign2 = -1;

      char oper = argv[2][0];
      char data; //to store each character

      /*create list for operand1 */
      int j = 0;
      if(argv[1][0] == '-' || argv[1][0] == '+')
      {
         j = 1; //skip sign
      }
      else
      {
        j = 0; //no sign, start from first character
      }
      for(int i = j;argv[1][i] != '\0';i++)
        {
            data = argv[1][i] - '0';
            insert_last(&head1,&tail1,data);
        }

        /*create list for operand2 */
        int k = 0;
        if(argv[3][0] == '-' || argv[3][0] == '+')
        {
            k = 1; //skip sign
        }
        else
        {
            k = 0; //no sign, start from first character
        }
        for(int i = k;argv[3][i] != '\0';i++)
        {
            data = argv[3][i] - '0';
            insert_last(&head2,&tail2,data);
        }
        /* Remove leading zeros from both operands */
        remove_pre_zeros(&head1,&tail1);
        remove_pre_zeros(&head2,&tail2);
        
    printf(YELLOW "Operand1:\n" RESET);
    print_list(&head1,&tail1);

    printf(PURPLE "Operator: %c\n" RESET, oper);

    printf(YELLOW "Operand2:\n" RESET);
    print_list(&head2,&tail2);

    //Animation for the result
    char str[30] = "Calculating Result...";
    for(int i = 0; str[i] != '\0'; i++)
    {
        printf(ORANGE "%c" RESET, str[i]);
        fflush(stdout); // Flush the output buffer to ensure immediate display
        usleep(100000); // Sleep for 100 milliseconds (adjust as needed)
    }

    printf(BLUE "\n-----RESULT IS-----\n" RESET);

    
    switch(oper)
    {
        case '+':
            if(sign1 == sign2)/*check both signs are same */
            {
                addition(tail1,tail2,&headR,&tailR); /*add both operands */  
                if(sign1 == -1) /*if both operands are negative then result is also negative */
                {
                    //if(headR != NULL)
                        headR->data *= -1;
                }
            }
            else
            {
                if(compare_list(head1, head2) == OPERAND1) /*if operand1 is greater than operand2 */
                {
                    subtraction(tail1, tail2, &headR, &tailR);
                    if(sign1 == -1) /*if operand1 is negative then result is also negative */
                    {
                        // if(headR != NULL)
                           headR->data *= -1;
                    }
                }
                else if(compare_list(head1, head2) == OPERAND2) /*if operand2 is greater than operand1 */
                {
                    subtraction(tail2, tail1, &headR, &tailR);
                    if(sign2 == -1) /*if operand2 is negative then result is also negative */
                    {
                       // printf("-");
                        //if(headR != NULL)
                            headR->data *= -1;
                    }
                }
                else /*if both operands are equal then result is zero */
                {
                    insert_first(&headR, &tailR, 0);
                }
            }
            remove_pre_zeros(&headR, &tailR);
            if(headR != NULL)
            {
                print_list(&headR, &tailR);
            }
            break;
       case '-':
            if(sign1 != sign2) /*if both signs are different then add both operands */
            {
                addition(tail1, tail2, &headR, &tailR);
                if(sign1 == -1) /*if operand1 is negative then result is also negative */
                {
                    //if(headR != NULL)
                        headR->data *= -1;
                }
            }
            else /*if both signs are same then subtract both operands */
            {
               if( compare_list(head1, head2) == OPERAND1)
               {
                    subtraction(tail1, tail2, &headR, &tailR);
                    if(sign1 == -1) /*if operand1 is negative then result is also negative */
                    {
                        // if(headR != NULL)
                            headR->data *= -1;
                    }
               }
               else if(compare_list(head1, head2) == OPERAND2)
               {
                    subtraction(tail2, tail1, &headR, &tailR);
                    // if(sign2 == -1) /*if operand2 is negative then result is also negative */
                    // {
                        //if(headR != NULL)
                           headR->data *= -1;
                    //}
               }
               else /*if both operands are equal then result is zero */
               {
                    insert_first(&headR, &tailR, 0);
               }
            }
        
            remove_pre_zeros(&headR, &tailR);
            if(headR != NULL)
            {
                print_list(&headR, &tailR);
            }
            break;
        case 'x':
        case 'X':
        case '*':
                if(sign1 != sign2) /*if both signs are different then result is negative */
                {
                    multiplication(tail1, tail2, &headR, &tailR);
                    if(headR != NULL)
                        headR->data *= -1;
                }
                else /*if both signs are same then result is positive */
                {
                    multiplication(tail1, tail2, &headR, &tailR);
                }
             if(headR != NULL)
            {
                print_list(&headR,&tailR);
            }
            break;
        case '/':
                if(head2->data == 0 && head2->next == NULL)
                {
                    printf(RED "ERROR: Division by zero not allowed\n" RESET);
                    return -1;
                }
                if(sign1 != sign2) /*if both signs are different then result is negative */
                {
                    int res = division(head1,tail1,head2,tail2,&headR,&tailR);
                    //if(headR != NULL)
                       // headR->data *= -1;
                       if(res != 0)
                         printf(GREEN " -%d\n" RESET, res);
                       else
                         printf(GREEN " %d\n" RESET, res);
                }
                else /*if both signs are same then result is positive */
                {
                    int res=division(head1,tail1,head2,tail2,&headR,&tailR);
                    printf(GREEN " %d\n" RESET, res);
                }
                remove_pre_zeros(&headR, &tailR);
            //  if(headR != NULL)
            //  {
            //     print_list(&headR, &tailR);
            //  }
            break;
        default:
            printf(RED "Error : Invalid operator\n" RESET);
            printf("Valid operators : + - / * x X\n");
            return -1;
    }
    }
    return 0;
}